using Auth.Models;
using Auth.Models.Requests;

namespace Auth.Services.PostgresDbService;

public interface IUserService
{
    void RegisterUser(RegisterRequest request);

    public string AuthorizeUserAndGetToken(AuthorizeRequest request);
    
    User GetUserById(long id);
}