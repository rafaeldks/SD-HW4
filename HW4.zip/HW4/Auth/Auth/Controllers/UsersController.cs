using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Auth.Models;
using Auth.Models.Requests;
using Auth.Services.Exceptions;
using Auth.Services.PostgresDbService;

namespace Auth.Controllers;

[ApiController]
[Route("api/v1/user")]
public class UsersController : ControllerBase
{
    private IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    /// <summary>
    /// Осуществляет регистрацию пользователя.
    /// </summary>
    /// <param name="request">Тело запроса регистрации.</param>
    /// <returns></returns>
    [AllowAnonymous]
    [HttpPost("register")]
    public IActionResult RegisterUser(RegisterRequest request)
    {
        try
        {
            _userService.RegisterUser(request);
            return Ok(new {message = "Пользователь успешно зарегистрирован!"});
        }
        catch (UserAlreadyExistException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
    
    /// <summary>
    /// Авторизирует пользователя.
    /// </summary>
    /// <param name="request">Тело запроса авторизации.</param>
    /// <returns>JWT токен авторизации.</returns>
    [AllowAnonymous]
    [HttpPost("auth")]
    public IActionResult AuthorizeUser(AuthorizeRequest request)
    {
        try
        {
            var response = _userService.AuthorizeUserAndGetToken(request);
            return Ok(new {token = response});
        }
        catch (AuthException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
    
    /// <summary>
    /// Возвращает информауию о текущем авторизированном пользователе.
    /// </summary>
    /// <returns>Информация о пользователе.</returns>
    [Helpers.Authorize]
    [HttpGet("info")]
    public IActionResult GetInfo()
    {
        var userInfo = (User)HttpContext.Items["User"];
        return Ok(userInfo);
    }
}