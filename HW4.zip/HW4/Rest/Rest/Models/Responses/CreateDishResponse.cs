namespace Rest.Models.Responses;

public class CreateDishResponse
{
    public long CreatedDishId { get; set; }
}