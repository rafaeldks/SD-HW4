using Microsoft.AspNetCore.Mvc;

using Rest.Helpers;
using Rest.Models.Requests;
using Rest.Services.Exceptions;
using Rest.Services.Interfaces;

namespace Rest.Controllers;

[ApiController]
[Route("api/v1/dish")]
public class DishController : ControllerBase
{
    private IDishService _dishService;

    public DishController(IDishService dishService)
    {
        _dishService = dishService;
    }

    /// <summary>
    /// Добавляет новое блюдо в меню.
    /// </summary>
    /// <param name="request">Тело запроса.</param>
    /// <returns>Id созданного блюда.</returns>
    [ManagerAuthorize]
    [HttpPost("create")]
    public IActionResult CreateDish(CreateDishRequest request)
    {
        var response = _dishService.CreateDish(request);
        return Ok(response);
    }
    
    /// <summary>
    /// Получает информацию по запрошенным блюдам.
    /// </summary>
    /// <param name="request">Id запрашиваемых блюд. Если указать пустым, вернется информация по всем блюдам.</param>
    /// <returns>Информация по запрошенным блюдам.</returns>
    [ManagerAuthorize]
    [HttpPost]
    public IActionResult GetDishesInfo(GetDishesInfoRequest request)
    {
        var response = _dishService.GetDishesInfo(request);
        return Ok(response);
    }
    
    /// <summary>
    /// Удаляет блюдо из меню.
    /// </summary>
    /// <param name="dishId">Id блюда, которое нужно удалить.</param>
    /// <returns></returns>
    [ManagerAuthorize]
    [HttpDelete("remove/{dishId:long:min(0)}")]
    public IActionResult RemoveDish(long dishId)
    {
        try
        {
            _dishService.RemoveDish(dishId);
            return Ok();
        }
        catch (DishNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    /// <summary>
    /// По id блюда позволяет частично или полностью изменить информацию о нем.
    /// </summary>
    /// <param name="dishId">Id блюда.</param>
    /// <param name="request">Тело, в котором указывается, какие поля и на что поменять.</param>
    /// <returns></returns>
    [ManagerAuthorize]
    [HttpPatch("change/{dishId:long:min(0)}")]
    public IActionResult ChangeDish(long dishId,
        [FromBody] ChangeDishRequest request)
    {
        try
        {
            _dishService.ChangeDish(dishId, request);
            return Ok();
        }
        catch (DishNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }
    
    /// <summary>
    /// Получает доступные в меню блюда.
    /// </summary>
    /// <returns>Информация о блюдах.</returns>
    [DefaultAuthorize]
    [HttpGet("available")]
    public IActionResult GetAvailableDishesInfo()
    {
        var response = _dishService.GetAvailableDishesInfo();
        return Ok(response);
    }
}