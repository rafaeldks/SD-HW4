using Microsoft.AspNetCore.Mvc;

using Rest.Helpers;
using Rest.Models.Requests;
using Rest.Services.Exceptions;
using Rest.Services.Interfaces;

namespace Rest.Controllers;

[ApiController]
[Route("api/v1/order")]
public class OrderController : ControllerBase
{
    private IOrderService _orderService;

    public OrderController(IOrderService orderService)
    {
        _orderService = orderService;
    }

    /// <summary>
    /// Создает новый заказ.
    /// </summary>
    /// <param name="request">Детали заказа.</param>
    /// <returns>Id созданного заказа.</returns>
    [DefaultAuthorize]
    [HttpPost("create")]
    public IActionResult CreateDish(CreateOrderRequest request)
    {
        try
        {
            var userId = (int)HttpContext.Items["UserId"];
            var orderId = _orderService.CreateOrder(request, userId);
            return Ok(new { message = "Заказ успешно создан.", orderId = orderId });
        }
        catch (IncorrectOrderException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
    
    /// <summary>
    /// Получает информацию о заказе.
    /// </summary>
    /// <param name="orderId">Id заказа</param>
    /// <returns>Информация по заказу.</returns>
    [DefaultAuthorize]
    [HttpGet("info/{orderId:long:min(0)}")]
    public IActionResult GetInfo(long orderId)
    {
        try
        {
            var response = _orderService.GetInfo(orderId);
            return Ok(response);
        }
        catch (OrderNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }
}