

using Rest.Models.Requests;
using Rest.Models.Responses;
using Rest.Services.Interfaces;
using Rest.Services.PostgresDbService.Models;

namespace Rest.Services;

public class DishService : IDishService
{

    // private readonly AppSettings _appSettings;
    private readonly IDbService _db;

    public DishService(IDbService db)
    {
        // _appSettings = appSettings.Value;
        _db = db;
    }

    public CreateDishResponse CreateDish(CreateDishRequest request)
    {
        Dish dish = new Dish
        {
            Name = request.Name,
            Price = request.Price,
            Description = request.Description,
            Quantity = request.Quantity,
            IsAvailable = request.IsAvailable
        };
        var dishId = _db.CreateDishAndGetId(dish);
        return new CreateDishResponse { CreatedDishId = dishId };
    }

    public GetDishesInfoResponse GetDishesInfo(GetDishesInfoRequest request)
    {
        List<Dish> dishes;
        if (request.RequiredIds.Count == 0)
        {
            dishes = _db.GetAllDishes();
        }
        else
        {
            dishes = _db.GetDishesInfoByIds(request.RequiredIds);
        }
        return new GetDishesInfoResponse
        {
            Dishes = dishes
        };
    }

    public GetDishesInfoResponse GetAvailableDishesInfo()
    {
        var dishes = _db.GetAvailableDishes();
        return new GetDishesInfoResponse { Dishes = dishes };
    }

    public void RemoveDish(long dishId)
    {
        _db.RemoveDish(dishId);
    }

    public void ChangeDish(long dishId, ChangeDishRequest request)
    {
        _db.ChangeDish(dishId, request);
    }
}