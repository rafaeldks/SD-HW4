using Rest.Models.Requests;
using Rest.Models.Responses;

namespace Rest.Services.Interfaces;

public interface IOrderService
{
    public long CreateOrder(CreateOrderRequest request, long userId);

    public GetOrderResponse GetInfo(long orderId);
}