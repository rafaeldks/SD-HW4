using Rest.Models.Requests;
using Rest.Models.Responses;

namespace Rest.Services.Interfaces;

public interface IDishService
{
    public CreateDishResponse CreateDish(CreateDishRequest request);
    public GetDishesInfoResponse GetDishesInfo(GetDishesInfoRequest request);

    public void RemoveDish(long dishId);

    public void ChangeDish(long dishId, ChangeDishRequest request);
    
    public GetDishesInfoResponse GetAvailableDishesInfo();
}